frontend-nanodegree-arcade-game
===============================
This readme contains: 
1.	About
2.	System requirements
	phone
	desktop
3.	How to run this game
4.	How to play
5.	How to score
6.	Final Message
===============================
1	About:
	This game is a clone of classic arcade game "Frogger". The cloned version is web-ready and is made using HTML canvas and JavaScript instead of traditional approach involving flash.

2.	System Requirements:
	Smartphone:
		Android/iOS/Windows Phone with any JavaScript enabled browser like firefox, chrome etc.
	Desktop:
		Windows (7 or later), MacOS (X or later), Linux and other operating systems with JavaScript enabled browser like firefox, chrome etc. 

3.	How to run this game:
	open the index.html file in your browser and you are good to go !!

4.	How to Play:
	Use arrow keys to control the player, help him reach till water. Beware of the bugs in the garden.

5.	Scoring
	Each time you cross the garden, you get one point, score of 0 to 3 is considered very low, till 10 is good and if you can score beyond 20, you are a pro !!

6.	Final Message
	Thank to you for trying out this game. I hope this will bring back some old memories of the time we (the 90's generation)
	played arcade games on our old computers and those vending machines (oh boy, those days...). And to those who are new to this game, I'm sure you'll love it too :)

